package com.java.project;

import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController

@RequestMapping("/emps")
public class EmployeeController {
	
	
	EmployeeDAOImpl empDao = new EmployeeDAOImpl(); // MODEL
			
	@RequestMapping("/") // assume default for localhost:8080/emps/
	List<Employee >getAllEmployees() {
		
		return empDao.findAllEmployees();
	}
	
	
	@RequestMapping("/getEmp/{eno}") // localhost:8080/emps/getEmp/101
	Employee getSingleEmployee(@PathVariable("eno") int x) {
		
		return empDao.findEmployee(x);
	}

}
