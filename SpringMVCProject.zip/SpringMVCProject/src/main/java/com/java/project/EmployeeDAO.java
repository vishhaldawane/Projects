package com.java.project;

import java.util.List;

public interface EmployeeDAO {
	void addEmployee(Employee e);
	void updateEmployee(Employee e);
	void deleteEmployee(int e);
	Employee findEmployee(int e);
	List<Employee> findAllEmployees( );
	
}
