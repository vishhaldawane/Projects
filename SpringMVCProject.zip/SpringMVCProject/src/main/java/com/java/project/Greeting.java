package com.java.project;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController

@RequestMapping("/greetings")
public class Greeting {

	
	@RequestMapping("/greet") //URL pattern -> http://localhost:8080/greetings/greet
	String sayHello1() {
		System.out.println("sayHello() invoked....");
		return "<h1>Greeting: Greet Web App</h1>";
	}
	
	@RequestMapping("/hi") //URL pattern -> http://localhost:8080/greetings/hi
	String sayHi2() {
		System.out.println("sayHi() invoked....");
		return "<h2>Greeting: Hi Web App</h2>";
	}
	
	@RequestMapping("/bye") //URL pattern -> http://localhost:8080/greetings/bye
	String sayBye3() {
		System.out.println("sayBye() invoked....");
		return "<h3>Greeting: Bye Web App</h3>";
	}
	
}

/*


http://localhost:8080/greet --> DispatcherServlet
									|
							--------------------
							|				|
						Controller		RestController
						|
				---------------
				|			|
				Model		View
							

*/