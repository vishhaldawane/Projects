package com.java.project;

import java.util.ArrayList;
import java.util.List;

public class EmployeeDAOImpl implements EmployeeDAO {

	List<Employee> staff = new ArrayList<Employee>();
	
	
	public EmployeeDAOImpl() {
		System.out.println("EmployeeDAOImpl() ctor....");
		Employee emp1 = new Employee(101,"jack",50000);
		Employee emp2 = new Employee(102,"jacky",60000);
		Employee emp3 = new Employee(103,"jane",70000);
		Employee emp4 = new Employee(104,"julie",80000);
		Employee emp5 = new Employee(105,"julia",90000);
		
		staff.add(emp1);
		staff.add(emp2);
		staff.add(emp3);
		staff.add(emp4);
		staff.add(emp5);
		
		

		
	}
	
	public void addEmployee(Employee e) {
		// TODO Auto-generated method stub
		staff.add(e);

	}

	
	public void updateEmployee(Employee e) {
		// TODO Auto-generated method stub
		for(Employee emp : staff) {
			if(emp.getEmployeeNumber() == e.getEmployeeNumber()) {
				staff.remove(emp); //remove if found - remove old jane's details
				staff.add(e); //and welcome the new object which has new details for jane
				break;
			}
		}
	}


	public void deleteEmployee(int e) {
		// TODO Auto-generated method stub
		for(Employee emp : staff) {
			if(emp.getEmployeeNumber() == e) {
				staff.remove(emp);

				break;
			}
		}
	}


	public Employee findEmployee(int e) {
		// TODO Auto-generated method stub
		Employee tempEmp = null;
		
		for(Employee emp : staff) {
			if(emp.getEmployeeNumber() == e) {
				tempEmp = emp;
				break;
			}
		}
		return tempEmp;
	}


	public List<Employee> findAllEmployees() {
		// TODO Auto-generated method stub
		return staff;
	}

}
