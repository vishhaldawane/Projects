package com.java.project;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
/*
 * 
 * 
 * 
 * 	Controller
 * 
 * 
 * M		V		
 * |			|
 * AL			angular | JSP
 * |
 * ArrayList
 * 
 */
@RestController
@RequestMapping("/welcoming")
public class Welcome {

	
	@RequestMapping("/greet") //URL pattern -> http://localhost:8080/welcoming/greet
	String sayHello4() {
		System.out.println("sayHello() invoked....");
		return "<h1>Welcome: Greet Web App</h1>";
	}
	
	@RequestMapping("/hi") //URL pattern -> http://localhost:8080/welcoming/hi
	String sayHi5() {
		System.out.println("sayHi() invoked....");
		return "<h2>Welcome: Hi Web App</h2>";
	}
	
	@RequestMapping("/bye") //URL pattern -> http://localhost:8080/welcoming/bye
	String sayBye6() {
		System.out.println("Welcome: sayBye() invoked....");
		return "<h3>Welcome: Bye Web App</h3>";
	}
	
}

/*


http://localhost:8080/greet --> DispatcherServlet
									|
							--------------------
							|				|
						Controller		RestController
						|
				---------------
				|			|
				Model		View
							

*/