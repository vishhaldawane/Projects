
public class Diagram {

}
/*



					Emp + EmpDao < === MODEL -> DB
					
	
					EmpController <== CONTROLLER
					
					
					JSP pages <=== VIEW
					
					
						SpringMVCCRUDSimple
							|
					-----------------
					|
					WEB-INF
					|
				-----------
				|		|
				jsp		web.xml
						spring-servelet.xml <-- spring mvc configuration
						preeti-servlet.xml
	



1. tomcat reads -> web.xml
2. as per web.xml -> servlet name is ->spring ( it can be any name )

3. it would read -> spring-servlet.xml
			which has all the beans mapped and required
			for spring mvc
			
4. if the user runs the app
		http://localhost:8080/SpringMVCCRUDSimple/  -> index.jsp
		
		index.jsp
		|
		<a href="empform">Add Employee</a>
		<a href="viewemp">View Employees</a>
			
			
			empform.jsp -> setting can be found in spring-servlet.xml
			viewemp.jsp


 spring-servlet.xml - line 11 would scan the controller
 line 13-16 -> prefix -suffix path
 
 line 18-23 -> data source
 
*/




